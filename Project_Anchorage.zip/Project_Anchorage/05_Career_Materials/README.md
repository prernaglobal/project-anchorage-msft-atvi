# Career Materials — Status

This folder is a placeholder. The main README references resume bullets, a LinkedIn post,
and interview talking points tied to this project — add them here, or remove the folder
and the reference in the main README if you don't plan to include them.
