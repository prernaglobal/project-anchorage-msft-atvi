# Financial Models — Status

Included:
- Financial_Model_-_Merger_Analysis.xlsx (sources & uses, PPA, pro forma combination, accretion/dilution)
- Comparable_Transactions_Analysis.xlsx (precedent gaming M&A transactions)

Still to add (referenced in the main README but not yet in this folder):
- DCF Model (5-year unlevered FCF, WACC/CAPM, sensitivity grid)
- Comparable Companies Analysis (EA, Take-Two, Ubisoft, ATVI trading multiples)
